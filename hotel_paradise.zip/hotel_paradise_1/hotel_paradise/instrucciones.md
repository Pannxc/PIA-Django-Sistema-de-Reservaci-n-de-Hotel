# Hotel Paradise - Sistema de reservación de hotel

Producto Integrador de Aprendizaje (PIA) desarrollado con Django, SQLite y Bootstrap 5.

## Cómo ejecutar el proyecto

1. Crear y activar el entorno virtual:

```
python -m venv venv
venv\Scripts\activate
```

En Linux o Mac se activa con `source venv/bin/activate`.

2. Instalar las dependencias:

```
pip install -r requirements.txt
```

3. Crear la base de datos:

```
python manage.py migrate
```

4. Crear el usuario administrador (con este usuario se inicia sesión en el sistema):

```
python manage.py createsuperuser
```

5. Iniciar el servidor:

```
python manage.py runserver
```

6. Abrir `http://127.0.0.1:8000/` en el navegador e iniciar sesión.

Se necesita conexión a internet para que Bootstrap 5 cargue desde su CDN.

Más usuarios se pueden crear desde el panel de administración en `http://127.0.0.1:8000/admin/`.

## Pruebas

```
python manage.py test
```

## Estructura

```
hotel_paradise/
    manage.py
    requirements.txt
    hotel_paradise/      configuración del proyecto (settings.py, urls.py)
    hotel/               aplicación principal
        models.py        Habitacion, Cliente y Reservacion
        forms.py         formularios y reglas de negocio
        views.py         vistas del sistema
        urls.py          rutas de la aplicación
        admin.py         configuración del panel de administración
        tests.py         pruebas automáticas
        migrations/
    templates/           plantillas HTML con Bootstrap 5
```
