import os
import sys


def main():
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'hotel_paradise.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as error:
        raise ImportError(
            'No se pudo importar Django. Verifica que esté instalado y que el entorno virtual esté activado.'
        ) from error
    execute_from_command_line(sys.argv)


if __name__ == '__main__':
    main()
