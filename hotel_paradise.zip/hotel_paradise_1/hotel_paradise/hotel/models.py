from django.core.validators import MinValueValidator, RegexValidator
from django.db import models


class Habitacion(models.Model):
    TIPOS = [
        ('Individual', 'Individual'),
        ('Doble', 'Doble'),
        ('Suite', 'Suite'),
        ('Presidencial', 'Presidencial'),
    ]

    numero = models.PositiveIntegerField(
        unique=True,
        validators=[MinValueValidator(1)],
        verbose_name='Número de habitación',
    )
    tipo = models.CharField(max_length=20, choices=TIPOS)
    precio_noche = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        validators=[MinValueValidator(1)],
        verbose_name='Precio por noche',
    )
    capacidad = models.PositiveIntegerField(
        validators=[MinValueValidator(1)],
        verbose_name='Capacidad (personas)',
    )
    disponible = models.BooleanField(
        default=True,
        help_text='Si lo desmarcas, la habitación no aparece al crear reservaciones.',
    )
    imagen = models.ImageField(upload_to='habitaciones/', blank=True)

    class Meta:
        ordering = ['numero']
        verbose_name = 'Habitación'
        verbose_name_plural = 'Habitaciones'

    def __str__(self):
        return f'Habitación {self.numero} - {self.tipo}'


class Cliente(models.Model):
    nombre = models.CharField(max_length=100)
    apellidos = models.CharField(max_length=150)
    correo = models.EmailField(unique=True, verbose_name='Correo electrónico')
    telefono = models.CharField(
        max_length=20,
        validators=[
            RegexValidator(
                r'^\+?[0-9\s\-]{7,15}$',
                'Escribe un teléfono válido, solo con números (de 7 a 15 dígitos).',
            )
        ],
        verbose_name='Teléfono',
    )
    fecha_registro = models.DateField(auto_now_add=True, verbose_name='Fecha de registro')

    class Meta:
        ordering = ['apellidos', 'nombre']

    def __str__(self):
        return f'{self.nombre} {self.apellidos}'


class Reservacion(models.Model):
    ESTADOS = [
        ('Activa', 'Activa'),
        ('Cancelada', 'Cancelada'),
        ('Finalizada', 'Finalizada'),
    ]

    cliente = models.ForeignKey(
        Cliente,
        on_delete=models.CASCADE,
        related_name='reservaciones',
    )
    habitacion = models.ForeignKey(
        Habitacion,
        on_delete=models.CASCADE,
        related_name='reservaciones',
        verbose_name='Habitación',
    )
    fecha_entrada = models.DateField(verbose_name='Fecha de entrada')
    fecha_salida = models.DateField(verbose_name='Fecha de salida')
    total = models.DecimalField(max_digits=10, decimal_places=2, default=0, editable=False)
    estado = models.CharField(max_length=20, choices=ESTADOS, default='Activa')

    class Meta:
        ordering = ['-fecha_entrada']
        verbose_name = 'Reservación'
        verbose_name_plural = 'Reservaciones'

    def noches(self):
        return (self.fecha_salida - self.fecha_entrada).days

    def calcular_total(self):
        return self.noches() * self.habitacion.precio_noche

    def save(self, *args, **kwargs):
        self.total = self.calcular_total()
        super().save(*args, **kwargs)

    def __str__(self):
        return f'Reservación {self.pk} - {self.cliente} - Habitación {self.habitacion.numero}'
