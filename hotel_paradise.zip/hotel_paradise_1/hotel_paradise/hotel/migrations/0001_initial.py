import django.core.validators
import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = []

    operations = [
        migrations.CreateModel(
            name="Cliente",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                ("nombre", models.CharField(max_length=100)),
                ("apellidos", models.CharField(max_length=150)),
                (
                    "correo",
                    models.EmailField(
                        max_length=254, unique=True, verbose_name="Correo electrónico"
                    ),
                ),
                (
                    "telefono",
                    models.CharField(
                        max_length=20,
                        validators=[
                            django.core.validators.RegexValidator(
                                "^\\+?[0-9\\s\\-]{7,15}$",
                                "Escribe un teléfono válido, solo con números (de 7 a 15 dígitos).",
                            )
                        ],
                        verbose_name="Teléfono",
                    ),
                ),
                (
                    "fecha_registro",
                    models.DateField(
                        auto_now_add=True, verbose_name="Fecha de registro"
                    ),
                ),
            ],
            options={
                "ordering": ["apellidos", "nombre"],
            },
        ),
        migrations.CreateModel(
            name="Habitacion",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                (
                    "numero",
                    models.PositiveIntegerField(
                        unique=True,
                        validators=[django.core.validators.MinValueValidator(1)],
                        verbose_name="Número de habitación",
                    ),
                ),
                (
                    "tipo",
                    models.CharField(
                        choices=[
                            ("Individual", "Individual"),
                            ("Doble", "Doble"),
                            ("Suite", "Suite"),
                            ("Presidencial", "Presidencial"),
                        ],
                        max_length=20,
                    ),
                ),
                (
                    "precio_noche",
                    models.DecimalField(
                        decimal_places=2,
                        max_digits=8,
                        validators=[django.core.validators.MinValueValidator(1)],
                        verbose_name="Precio por noche",
                    ),
                ),
                (
                    "capacidad",
                    models.PositiveIntegerField(
                        validators=[django.core.validators.MinValueValidator(1)],
                        verbose_name="Capacidad (personas)",
                    ),
                ),
                (
                    "disponible",
                    models.BooleanField(
                        default=True,
                        help_text="Si lo desmarcas, la habitación no aparece al crear reservaciones.",
                    ),
                ),
                ("imagen", models.ImageField(blank=True, upload_to="habitaciones/")),
            ],
            options={
                "verbose_name": "Habitación",
                "verbose_name_plural": "Habitaciones",
                "ordering": ["numero"],
            },
        ),
        migrations.CreateModel(
            name="Reservacion",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                ("fecha_entrada", models.DateField(verbose_name="Fecha de entrada")),
                ("fecha_salida", models.DateField(verbose_name="Fecha de salida")),
                (
                    "total",
                    models.DecimalField(
                        decimal_places=2, default=0, editable=False, max_digits=10
                    ),
                ),
                (
                    "estado",
                    models.CharField(
                        choices=[
                            ("Activa", "Activa"),
                            ("Cancelada", "Cancelada"),
                            ("Finalizada", "Finalizada"),
                        ],
                        default="Activa",
                        max_length=20,
                    ),
                ),
                (
                    "cliente",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="reservaciones",
                        to="hotel.cliente",
                    ),
                ),
                (
                    "habitacion",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="reservaciones",
                        to="hotel.habitacion",
                        verbose_name="Habitación",
                    ),
                ),
            ],
            options={
                "verbose_name": "Reservación",
                "verbose_name_plural": "Reservaciones",
                "ordering": ["-fecha_entrada"],
            },
        ),
    ]
