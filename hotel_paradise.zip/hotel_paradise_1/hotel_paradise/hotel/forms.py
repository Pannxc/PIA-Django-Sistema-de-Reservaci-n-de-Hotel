from django import forms
from django.core.exceptions import ValidationError
from django.db.models import Q

from .models import Cliente, Habitacion, Reservacion


def aplicar_bootstrap(formulario):
    for campo in formulario.fields.values():
        if isinstance(campo.widget, forms.CheckboxInput):
            campo.widget.attrs['class'] = 'form-check-input'
        elif isinstance(campo.widget, forms.Select):
            campo.widget.attrs['class'] = 'form-select'
        else:
            campo.widget.attrs['class'] = 'form-control'


def fecha_corta(fecha):
    return fecha.strftime('%d/%m/%Y')


class HabitacionForm(forms.ModelForm):
    class Meta:
        model = Habitacion
        fields = ['numero', 'tipo', 'precio_noche', 'capacidad', 'disponible', 'imagen']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['tipo'].choices = [('', 'Selecciona un tipo')] + list(Habitacion.TIPOS)
        aplicar_bootstrap(self)

    def clean_numero(self):
        numero = self.cleaned_data['numero']
        repetida = Habitacion.objects.filter(numero=numero).exclude(pk=self.instance.pk)
        if repetida.exists():
            raise ValidationError(f'Ya existe una habitación con el número {numero}. Elige un número distinto.')
        return numero


class ClienteForm(forms.ModelForm):
    class Meta:
        model = Cliente
        fields = ['nombre', 'apellidos', 'correo', 'telefono']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        aplicar_bootstrap(self)

    def clean_correo(self):
        correo = self.cleaned_data['correo'].strip().lower()
        repetido = Cliente.objects.filter(correo__iexact=correo).exclude(pk=self.instance.pk)
        if repetido.exists():
            raise ValidationError(f'El correo {correo} ya está registrado con otro cliente.')
        return correo


class ReservacionForm(forms.ModelForm):
    class Meta:
        model = Reservacion
        fields = ['cliente', 'habitacion', 'fecha_entrada', 'fecha_salida', 'estado']
        widgets = {
            'fecha_entrada': forms.DateInput(attrs={'type': 'date'}, format='%Y-%m-%d'),
            'fecha_salida': forms.DateInput(attrs={'type': 'date'}, format='%Y-%m-%d'),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        habitaciones = Habitacion.objects.filter(disponible=True)
        if self.instance.pk:
            habitaciones = Habitacion.objects.filter(Q(disponible=True) | Q(pk=self.instance.habitacion_id))
        self.fields['habitacion'].queryset = habitaciones.order_by('numero')
        self.fields['cliente'].empty_label = 'Selecciona un cliente'
        self.fields['habitacion'].empty_label = 'Selecciona una habitación'
        aplicar_bootstrap(self)

    def clean(self):
        datos = super().clean()
        cliente = datos.get('cliente')
        habitacion = datos.get('habitacion')
        entrada = datos.get('fecha_entrada')
        salida = datos.get('fecha_salida')
        estado = datos.get('estado')

        if entrada and salida and salida <= entrada:
            self.add_error('fecha_salida', 'La fecha de salida debe ser mayor que la fecha de entrada.')
            return datos

        if habitacion and entrada and salida and estado == 'Activa':
            traslapes = Reservacion.objects.filter(
                habitacion=habitacion,
                estado='Activa',
                fecha_entrada__lt=salida,
                fecha_salida__gt=entrada,
            ).exclude(pk=self.instance.pk)
            if traslapes.exists():
                choque = traslapes.first()
                raise ValidationError(
                    f'La habitación {habitacion.numero} ya tiene una reservación activa del '
                    f'{fecha_corta(choque.fecha_entrada)} al {fecha_corta(choque.fecha_salida)} '
                    f'a nombre de {choque.cliente}. Elige otras fechas u otra habitación.'
                )
        return datos


class DisponibilidadForm(forms.Form):
    fecha_entrada = forms.DateField(
        label='Fecha de entrada',
        widget=forms.DateInput(attrs={'type': 'date'}, format='%Y-%m-%d'),
    )
    fecha_salida = forms.DateField(
        label='Fecha de salida',
        widget=forms.DateInput(attrs={'type': 'date'}, format='%Y-%m-%d'),
    )
    tipo = forms.ChoiceField(
        label='Tipo de habitación',
        required=False,
        choices=[('', 'Todos los tipos')] + Habitacion.TIPOS,
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        aplicar_bootstrap(self)

    def clean(self):
        datos = super().clean()
        entrada = datos.get('fecha_entrada')
        salida = datos.get('fecha_salida')
        if entrada and salida and salida <= entrada:
            self.add_error('fecha_salida', 'La fecha de salida debe ser mayor que la fecha de entrada.')
        return datos
