from datetime import timedelta
from decimal import Decimal

from django.contrib.auth.models import User
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from .models import Cliente, Habitacion, Reservacion


class BaseHotelTest(TestCase):
    def setUp(self):
        self.usuario = User.objects.create_user('recepcion', password='clave12345')
        self.client.force_login(self.usuario)
        self.hoy = timezone.localdate()
        self.habitacion = Habitacion.objects.create(numero=101, tipo='Doble', precio_noche=1000, capacidad=2)
        self.ana = Cliente.objects.create(
            nombre='Ana', apellidos='López Ruiz', correo='ana@correo.com', telefono='8112345678'
        )
        self.luis = Cliente.objects.create(
            nombre='Luis', apellidos='García Soto', correo='luis@correo.com', telefono='8187654321'
        )

    def dia(self, desplazamiento):
        return self.hoy + timedelta(days=desplazamiento)

    def reservar(self, cliente, habitacion, entrada, salida):
        return self.client.post(reverse('crear_reservacion'), {
            'cliente': cliente.pk,
            'habitacion': habitacion.pk,
            'fecha_entrada': entrada.isoformat(),
            'fecha_salida': salida.isoformat(),
            'estado': 'Activa',
        })


class ReglasDeNegocioTest(BaseHotelTest):
    def test_regla_1_no_permite_fechas_traslapadas(self):
        self.reservar(self.ana, self.habitacion, self.dia(10), self.dia(15))
        respuesta = self.reservar(self.luis, self.habitacion, self.dia(12), self.dia(18))
        self.assertEqual(respuesta.status_code, 200)
        self.assertContains(respuesta, 'ya tiene una reservación activa')
        self.assertEqual(Reservacion.objects.count(), 1)

    def test_regla_1_no_permite_reservacion_dentro_de_otra(self):
        self.reservar(self.ana, self.habitacion, self.dia(10), self.dia(20))
        respuesta = self.reservar(self.luis, self.habitacion, self.dia(12), self.dia(14))
        self.assertContains(respuesta, 'ya tiene una reservación activa')
        self.assertEqual(Reservacion.objects.count(), 1)

    def test_regla_1_permite_entrar_el_dia_de_salida_de_otra(self):
        self.reservar(self.ana, self.habitacion, self.dia(10), self.dia(15))
        respuesta = self.reservar(self.luis, self.habitacion, self.dia(15), self.dia(18))
        self.assertRedirects(respuesta, reverse('lista_reservaciones'))
        self.assertEqual(Reservacion.objects.count(), 2)

    def test_regla_1_ignora_reservaciones_canceladas(self):
        self.reservar(self.ana, self.habitacion, self.dia(10), self.dia(15))
        reservacion = Reservacion.objects.get()
        reservacion.estado = 'Cancelada'
        reservacion.save()
        respuesta = self.reservar(self.luis, self.habitacion, self.dia(11), self.dia(14))
        self.assertRedirects(respuesta, reverse('lista_reservaciones'))
        self.assertEqual(Reservacion.objects.count(), 2)

    def test_regla_1_al_editar_no_choca_con_ella_misma(self):
        self.reservar(self.ana, self.habitacion, self.dia(10), self.dia(15))
        reservacion = Reservacion.objects.get()
        respuesta = self.client.post(reverse('editar_reservacion', args=[reservacion.pk]), {
            'cliente': self.ana.pk,
            'habitacion': self.habitacion.pk,
            'fecha_entrada': self.dia(11).isoformat(),
            'fecha_salida': self.dia(16).isoformat(),
            'estado': 'Activa',
        })
        self.assertRedirects(respuesta, reverse('lista_reservaciones'))

    def test_regla_2_salida_debe_ser_mayor_que_entrada(self):
        respuesta = self.reservar(self.ana, self.habitacion, self.dia(10), self.dia(10))
        self.assertContains(respuesta, 'La fecha de salida debe ser mayor que la fecha de entrada.')
        respuesta = self.reservar(self.ana, self.habitacion, self.dia(10), self.dia(8))
        self.assertContains(respuesta, 'La fecha de salida debe ser mayor que la fecha de entrada.')
        self.assertEqual(Reservacion.objects.count(), 0)

    def test_regla_3_no_permite_numeros_de_habitacion_repetidos(self):
        respuesta = self.client.post(reverse('crear_habitacion'), {
            'numero': 101,
            'tipo': 'Suite',
            'precio_noche': '2500',
            'capacidad': 4,
            'disponible': 'on',
        })
        self.assertContains(respuesta, 'Ya existe una habitación con el número 101')
        self.assertEqual(Habitacion.objects.count(), 1)

    def test_regla_4_no_permite_correos_repetidos(self):
        datos = {'nombre': 'Pedro', 'apellidos': 'Torres', 'correo': 'ANA@correo.com', 'telefono': '8111111111'}
        respuesta = self.client.post(reverse('crear_cliente'), datos)
        self.assertContains(respuesta, 'ya está registrado con otro cliente')
        self.assertEqual(Cliente.objects.count(), 2)

    def test_regla_5_no_elimina_habitacion_con_reservaciones_activas(self):
        self.reservar(self.ana, self.habitacion, self.dia(10), self.dia(15))
        respuesta = self.client.post(reverse('eliminar_habitacion', args=[self.habitacion.pk]), follow=True)
        self.assertContains(respuesta, 'No se puede eliminar la habitación 101')
        self.assertTrue(Habitacion.objects.filter(pk=self.habitacion.pk).exists())

    def test_regla_5_elimina_habitacion_sin_reservaciones_activas(self):
        self.reservar(self.ana, self.habitacion, self.dia(10), self.dia(15))
        reservacion = Reservacion.objects.get()
        self.client.post(reverse('cancelar_reservacion', args=[reservacion.pk]))
        self.client.post(reverse('eliminar_habitacion', args=[self.habitacion.pk]))
        self.assertFalse(Habitacion.objects.filter(pk=self.habitacion.pk).exists())

    def test_no_elimina_cliente_con_reservaciones_activas(self):
        self.reservar(self.ana, self.habitacion, self.dia(10), self.dia(15))
        respuesta = self.client.post(reverse('eliminar_cliente', args=[self.ana.pk]), follow=True)
        self.assertContains(respuesta, 'No se puede eliminar a Ana López Ruiz')
        self.assertTrue(Cliente.objects.filter(pk=self.ana.pk).exists())


class FuncionalidadesTest(BaseHotelTest):
    def test_total_se_calcula_con_noches_y_precio(self):
        self.reservar(self.ana, self.habitacion, self.dia(10), self.dia(13))
        reservacion = Reservacion.objects.get()
        self.assertEqual(reservacion.noches(), 3)
        self.assertEqual(reservacion.total, Decimal('3000.00'))

    def test_cancelar_cambia_el_estado(self):
        self.reservar(self.ana, self.habitacion, self.dia(10), self.dia(13))
        reservacion = Reservacion.objects.get()
        self.client.post(reverse('cancelar_reservacion', args=[reservacion.pk]))
        reservacion.refresh_from_db()
        self.assertEqual(reservacion.estado, 'Cancelada')

    def test_las_vistas_exigen_inicio_de_sesion(self):
        self.client.logout()
        for nombre in ['dashboard', 'lista_habitaciones', 'lista_clientes', 'lista_reservaciones', 'consultar_disponibilidad']:
            respuesta = self.client.get(reverse(nombre))
            self.assertEqual(respuesta.status_code, 302)
            self.assertIn(reverse('login'), respuesta.url)

    def test_login_y_logout(self):
        self.client.logout()
        respuesta = self.client.post(reverse('login'), {'username': 'recepcion', 'password': 'clave12345'})
        self.assertRedirects(respuesta, reverse('dashboard'))
        self.client.logout()
        respuesta = self.client.post(reverse('login'), {'username': 'recepcion', 'password': 'incorrecta'})
        self.assertContains(respuesta, 'Usuario o contraseña incorrectos')
        self.client.post(reverse('logout'))
        self.assertEqual(self.client.get(reverse('dashboard')).status_code, 302)

    def test_dashboard_muestra_los_cinco_indicadores(self):
        Habitacion.objects.create(numero=102, tipo='Suite', precio_noche=2000, capacidad=3, disponible=False)
        self.reservar(self.ana, self.habitacion, self.dia(-1), self.dia(2))
        respuesta = self.client.get(reverse('dashboard'))
        self.assertEqual(respuesta.context['total_clientes'], 2)
        self.assertEqual(respuesta.context['total_habitaciones'], 2)
        self.assertEqual(respuesta.context['total_reservaciones'], 1)
        self.assertEqual(respuesta.context['habitaciones_disponibles'], 0)
        self.assertEqual(respuesta.context['ingresos'], Decimal('3000.00'))
        for texto in ['Total de Clientes', 'Total de Habitaciones', 'Total de Reservaciones',
                      'Habitaciones Disponibles', 'Ingresos Generados']:
            self.assertContains(respuesta, texto)

    def test_ingresos_no_incluyen_reservaciones_canceladas(self):
        self.reservar(self.ana, self.habitacion, self.dia(10), self.dia(12))
        reservacion = Reservacion.objects.get()
        self.client.post(reverse('cancelar_reservacion', args=[reservacion.pk]))
        respuesta = self.client.get(reverse('dashboard'))
        self.assertEqual(respuesta.context['ingresos'], 0)
        self.assertEqual(respuesta.context['total_reservaciones'], 1)

    def test_busqueda_de_reservaciones_por_cliente_habitacion_y_tipo(self):
        suite = Habitacion.objects.create(numero=201, tipo='Suite', precio_noche=2500, capacidad=4)
        self.reservar(self.ana, self.habitacion, self.dia(10), self.dia(12))
        self.reservar(self.luis, suite, self.dia(10), self.dia(12))
        url = reverse('lista_reservaciones')
        self.assertEqual(len(self.client.get(url, {'cliente': 'Ana López'}).context['reservaciones']), 1)
        self.assertEqual(len(self.client.get(url, {'habitacion': '201'}).context['reservaciones']), 1)
        self.assertEqual(len(self.client.get(url, {'tipo': 'Suite'}).context['reservaciones']), 1)
        self.assertEqual(len(self.client.get(url).context['reservaciones']), 2)

    def test_busqueda_de_clientes_y_habitaciones(self):
        respuesta = self.client.get(reverse('lista_clientes'), {'q': 'luis garcía'})
        self.assertEqual(list(respuesta.context['clientes']), [self.luis])
        respuesta = self.client.get(reverse('lista_habitaciones'), {'numero': '10', 'tipo': 'Doble'})
        self.assertEqual(list(respuesta.context['habitaciones']), [self.habitacion])

    def test_consulta_de_disponibilidad(self):
        otra = Habitacion.objects.create(numero=102, tipo='Doble', precio_noche=1200, capacidad=2)
        self.reservar(self.ana, self.habitacion, self.dia(10), self.dia(15))
        respuesta = self.client.get(reverse('consultar_disponibilidad'), {
            'fecha_entrada': self.dia(12).isoformat(),
            'fecha_salida': self.dia(14).isoformat(),
            'tipo': '',
        })
        habitaciones = [r['habitacion'] for r in respuesta.context['resultados']]
        self.assertEqual(habitaciones, [otra])

    def test_habitacion_no_disponible_no_aparece_al_reservar(self):
        Habitacion.objects.create(numero=103, tipo='Suite', precio_noche=2000, capacidad=3, disponible=False)
        respuesta = self.client.get(reverse('crear_reservacion'))
        numeros = [h.numero for h in respuesta.context['formulario'].fields['habitacion'].queryset]
        self.assertEqual(numeros, [101])

    def test_crud_de_habitacion_y_cliente(self):
        self.client.post(reverse('crear_habitacion'), {
            'numero': 301, 'tipo': 'Presidencial', 'precio_noche': '5000', 'capacidad': 6, 'disponible': 'on',
        })
        habitacion = Habitacion.objects.get(numero=301)
        self.client.post(reverse('editar_habitacion', args=[habitacion.pk]), {
            'numero': 301, 'tipo': 'Presidencial', 'precio_noche': '5500', 'capacidad': 6, 'disponible': 'on',
        })
        habitacion.refresh_from_db()
        self.assertEqual(habitacion.precio_noche, Decimal('5500.00'))
        self.client.post(reverse('eliminar_habitacion', args=[habitacion.pk]))
        self.assertFalse(Habitacion.objects.filter(numero=301).exists())

        self.client.post(reverse('crear_cliente'), {
            'nombre': 'Marta', 'apellidos': 'Díaz', 'correo': 'marta@correo.com', 'telefono': '8100000000',
        })
        cliente = Cliente.objects.get(correo='marta@correo.com')
        self.client.post(reverse('editar_cliente', args=[cliente.pk]), {
            'nombre': 'Marta', 'apellidos': 'Díaz Cruz', 'correo': 'marta@correo.com', 'telefono': '8100000000',
        })
        cliente.refresh_from_db()
        self.assertEqual(cliente.apellidos, 'Díaz Cruz')
        self.client.post(reverse('eliminar_cliente', args=[cliente.pk]))
        self.assertFalse(Cliente.objects.filter(correo='marta@correo.com').exists())
