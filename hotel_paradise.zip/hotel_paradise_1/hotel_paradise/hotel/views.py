from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db.models import Q, Sum
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from .forms import ClienteForm, DisponibilidadForm, HabitacionForm, ReservacionForm
from .models import Cliente, Habitacion, Reservacion


def habitaciones_ocupadas_hoy():
    hoy = timezone.localdate()
    ocupadas = Reservacion.objects.filter(
        estado='Activa',
        fecha_entrada__lte=hoy,
        fecha_salida__gt=hoy,
    )
    return list(ocupadas.values_list('habitacion_id', flat=True))


def texto_activas(cantidad):
    if cantidad == 1:
        return '1 reservación activa'
    return f'{cantidad} reservaciones activas'


@login_required
def dashboard(request):
    ocupadas = habitaciones_ocupadas_hoy()
    ingresos = Reservacion.objects.exclude(estado='Cancelada').aggregate(suma=Sum('total'))['suma'] or 0
    contexto = {
        'total_clientes': Cliente.objects.count(),
        'total_habitaciones': Habitacion.objects.count(),
        'total_reservaciones': Reservacion.objects.count(),
        'habitaciones_disponibles': Habitacion.objects.filter(disponible=True).exclude(id__in=ocupadas).count(),
        'ingresos': ingresos,
    }
    return render(request, 'dashboard.html', contexto)


@login_required
def lista_habitaciones(request):
    habitaciones = Habitacion.objects.all()
    numero = request.GET.get('numero', '').strip()
    tipo = request.GET.get('tipo', '')
    if numero:
        habitaciones = habitaciones.filter(numero__icontains=numero)
    if tipo:
        habitaciones = habitaciones.filter(tipo=tipo)
    contexto = {
        'habitaciones': habitaciones,
        'numero': numero,
        'tipo': tipo,
        'tipos': Habitacion.TIPOS,
        'ocupadas': habitaciones_ocupadas_hoy(),
    }
    return render(request, 'habitaciones/lista.html', contexto)


@login_required
def detalle_habitacion(request, pk):
    habitacion = get_object_or_404(Habitacion, pk=pk)
    contexto = {
        'habitacion': habitacion,
        'reservaciones': habitacion.reservaciones.select_related('cliente'),
        'ocupada': habitacion.pk in habitaciones_ocupadas_hoy(),
    }
    return render(request, 'habitaciones/detalle.html', contexto)


@login_required
def crear_habitacion(request):
    if request.method == 'POST':
        formulario = HabitacionForm(request.POST, request.FILES)
        if formulario.is_valid():
            habitacion = formulario.save()
            messages.success(request, f'La habitación {habitacion.numero} se registró correctamente.')
            return redirect('lista_habitaciones')
    else:
        formulario = HabitacionForm()
    contexto = {'formulario': formulario, 'titulo': 'Nueva habitación', 'volver': 'lista_habitaciones'}
    return render(request, 'formulario.html', contexto)


@login_required
def editar_habitacion(request, pk):
    habitacion = get_object_or_404(Habitacion, pk=pk)
    if request.method == 'POST':
        formulario = HabitacionForm(request.POST, request.FILES, instance=habitacion)
        if formulario.is_valid():
            formulario.save()
            messages.success(request, f'La habitación {habitacion.numero} se actualizó correctamente.')
            return redirect('lista_habitaciones')
    else:
        formulario = HabitacionForm(instance=habitacion)
    contexto = {
        'formulario': formulario,
        'titulo': f'Editar habitación {habitacion.numero}',
        'volver': 'lista_habitaciones',
    }
    return render(request, 'formulario.html', contexto)


@login_required
def eliminar_habitacion(request, pk):
    habitacion = get_object_or_404(Habitacion, pk=pk)
    activas = habitacion.reservaciones.filter(estado='Activa').count()
    if activas > 0:
        messages.error(
            request,
            f'No se puede eliminar la habitación {habitacion.numero} porque tiene {texto_activas(activas)}. '
            'Cancélalas o márcalas como finalizadas antes de eliminarla.',
        )
        return redirect('lista_habitaciones')

    if request.method == 'POST':
        numero = habitacion.numero
        habitacion.delete()
        messages.success(request, f'La habitación {numero} se eliminó correctamente.')
        return redirect('lista_habitaciones')

    mensaje = f'¿Seguro que deseas eliminar la habitación {habitacion.numero} ({habitacion.tipo})?'
    historial = habitacion.reservaciones.count()
    if historial > 0:
        mensaje += ' También se borrarán sus reservaciones canceladas o finalizadas.'
    contexto = {
        'titulo': 'Eliminar habitación',
        'mensaje': mensaje,
        'texto_boton': 'Sí, eliminar',
        'clase_boton': 'btn-danger',
        'volver': 'lista_habitaciones',
    }
    return render(request, 'confirmar.html', contexto)


@login_required
def lista_clientes(request):
    clientes = Cliente.objects.all()
    busqueda = request.GET.get('q', '').strip()
    for palabra in busqueda.split():
        clientes = clientes.filter(
            Q(nombre__icontains=palabra)
            | Q(apellidos__icontains=palabra)
            | Q(correo__icontains=palabra)
            | Q(telefono__icontains=palabra)
        )
    return render(request, 'clientes/lista.html', {'clientes': clientes, 'busqueda': busqueda})


@login_required
def detalle_cliente(request, pk):
    cliente = get_object_or_404(Cliente, pk=pk)
    contexto = {
        'cliente': cliente,
        'reservaciones': cliente.reservaciones.select_related('habitacion'),
    }
    return render(request, 'clientes/detalle.html', contexto)


@login_required
def crear_cliente(request):
    if request.method == 'POST':
        formulario = ClienteForm(request.POST)
        if formulario.is_valid():
            cliente = formulario.save()
            messages.success(request, f'El cliente {cliente} se registró correctamente.')
            return redirect('lista_clientes')
    else:
        formulario = ClienteForm()
    contexto = {'formulario': formulario, 'titulo': 'Nuevo cliente', 'volver': 'lista_clientes'}
    return render(request, 'formulario.html', contexto)


@login_required
def editar_cliente(request, pk):
    cliente = get_object_or_404(Cliente, pk=pk)
    if request.method == 'POST':
        formulario = ClienteForm(request.POST, instance=cliente)
        if formulario.is_valid():
            formulario.save()
            messages.success(request, f'Los datos de {cliente} se actualizaron correctamente.')
            return redirect('lista_clientes')
    else:
        formulario = ClienteForm(instance=cliente)
    contexto = {'formulario': formulario, 'titulo': f'Editar cliente: {cliente}', 'volver': 'lista_clientes'}
    return render(request, 'formulario.html', contexto)


@login_required
def eliminar_cliente(request, pk):
    cliente = get_object_or_404(Cliente, pk=pk)
    activas = cliente.reservaciones.filter(estado='Activa').count()
    if activas > 0:
        messages.error(
            request,
            f'No se puede eliminar a {cliente} porque tiene {texto_activas(activas)}. '
            'Cancélalas o márcalas como finalizadas antes de eliminarlo.',
        )
        return redirect('lista_clientes')

    if request.method == 'POST':
        nombre = str(cliente)
        cliente.delete()
        messages.success(request, f'El cliente {nombre} se eliminó correctamente.')
        return redirect('lista_clientes')

    mensaje = f'¿Seguro que deseas eliminar al cliente {cliente}?'
    historial = cliente.reservaciones.count()
    if historial > 0:
        mensaje += ' También se borrarán sus reservaciones canceladas o finalizadas.'
    contexto = {
        'titulo': 'Eliminar cliente',
        'mensaje': mensaje,
        'texto_boton': 'Sí, eliminar',
        'clase_boton': 'btn-danger',
        'volver': 'lista_clientes',
    }
    return render(request, 'confirmar.html', contexto)


@login_required
def lista_reservaciones(request):
    reservaciones = Reservacion.objects.select_related('cliente', 'habitacion')
    cliente = request.GET.get('cliente', '').strip()
    habitacion = request.GET.get('habitacion', '').strip()
    tipo = request.GET.get('tipo', '')
    estado = request.GET.get('estado', '')

    for palabra in cliente.split():
        reservaciones = reservaciones.filter(
            Q(cliente__nombre__icontains=palabra)
            | Q(cliente__apellidos__icontains=palabra)
            | Q(cliente__correo__icontains=palabra)
        )
    if habitacion:
        reservaciones = reservaciones.filter(habitacion__numero__icontains=habitacion)
    if tipo:
        reservaciones = reservaciones.filter(habitacion__tipo=tipo)
    if estado:
        reservaciones = reservaciones.filter(estado=estado)

    contexto = {
        'reservaciones': reservaciones,
        'cliente': cliente,
        'habitacion': habitacion,
        'tipo': tipo,
        'estado': estado,
        'tipos': Habitacion.TIPOS,
        'estados': Reservacion.ESTADOS,
    }
    return render(request, 'reservaciones/lista.html', contexto)


@login_required
def detalle_reservacion(request, pk):
    reservacion = get_object_or_404(Reservacion.objects.select_related('cliente', 'habitacion'), pk=pk)
    return render(request, 'reservaciones/detalle.html', {'reservacion': reservacion})


@login_required
def crear_reservacion(request):
    if request.method == 'POST':
        formulario = ReservacionForm(request.POST)
        if formulario.is_valid():
            reservacion = formulario.save()
            messages.success(request, f'Reservación registrada correctamente. Total a pagar: ${reservacion.total:,.2f}')
            return redirect('lista_reservaciones')
    else:
        formulario = ReservacionForm(initial=request.GET.dict())
    contexto = {'formulario': formulario, 'titulo': 'Nueva reservación', 'volver': 'lista_reservaciones'}
    return render(request, 'formulario.html', contexto)


@login_required
def editar_reservacion(request, pk):
    reservacion = get_object_or_404(Reservacion, pk=pk)
    if request.method == 'POST':
        formulario = ReservacionForm(request.POST, instance=reservacion)
        if formulario.is_valid():
            reservacion = formulario.save()
            messages.success(request, f'La reservación {reservacion.pk} se actualizó correctamente.')
            return redirect('lista_reservaciones')
    else:
        formulario = ReservacionForm(instance=reservacion)
    contexto = {
        'formulario': formulario,
        'titulo': f'Editar reservación {reservacion.pk}',
        'volver': 'lista_reservaciones',
    }
    return render(request, 'formulario.html', contexto)


@login_required
def cancelar_reservacion(request, pk):
    reservacion = get_object_or_404(Reservacion, pk=pk)
    if reservacion.estado != 'Activa':
        messages.warning(request, f'Solo se pueden cancelar reservaciones activas. Esta está {reservacion.estado.lower()}.')
        return redirect('lista_reservaciones')

    if request.method == 'POST':
        reservacion.estado = 'Cancelada'
        reservacion.save()
        messages.success(request, f'La reservación {reservacion.pk} fue cancelada.')
        return redirect('lista_reservaciones')

    contexto = {
        'titulo': 'Cancelar reservación',
        'mensaje': (
            f'¿Seguro que deseas cancelar la reservación {reservacion.pk} de {reservacion.cliente} '
            f'en la habitación {reservacion.habitacion.numero}?'
        ),
        'texto_boton': 'Sí, cancelar reservación',
        'clase_boton': 'btn-danger',
        'volver': 'lista_reservaciones',
    }
    return render(request, 'confirmar.html', contexto)


@login_required
def consultar_disponibilidad(request):
    formulario = DisponibilidadForm(request.GET or None)
    contexto = {'formulario': formulario, 'resultados': None}
    if formulario.is_valid():
        entrada = formulario.cleaned_data['fecha_entrada']
        salida = formulario.cleaned_data['fecha_salida']
        tipo = formulario.cleaned_data['tipo']
        noches = (salida - entrada).days

        ocupadas = Reservacion.objects.filter(
            estado='Activa',
            fecha_entrada__lt=salida,
            fecha_salida__gt=entrada,
        ).values_list('habitacion_id', flat=True)
        libres = Habitacion.objects.filter(disponible=True).exclude(id__in=ocupadas)
        if tipo:
            libres = libres.filter(tipo=tipo)

        contexto['resultados'] = [
            {'habitacion': habitacion, 'total': habitacion.precio_noche * noches}
            for habitacion in libres
        ]
        contexto['entrada'] = entrada
        contexto['salida'] = salida
        contexto['noches'] = noches
    return render(request, 'disponibilidad.html', contexto)
