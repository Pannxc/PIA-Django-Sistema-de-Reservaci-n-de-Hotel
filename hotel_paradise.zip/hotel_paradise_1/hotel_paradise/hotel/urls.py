from django.contrib.auth import views as auth_views
from django.urls import path

from . import views

urlpatterns = [
    path('login/', auth_views.LoginView.as_view(template_name='login.html', redirect_authenticated_user=True), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),

    path('', views.dashboard, name='dashboard'),

    path('habitaciones/', views.lista_habitaciones, name='lista_habitaciones'),
    path('habitaciones/nueva/', views.crear_habitacion, name='crear_habitacion'),
    path('habitaciones/<int:pk>/', views.detalle_habitacion, name='detalle_habitacion'),
    path('habitaciones/<int:pk>/editar/', views.editar_habitacion, name='editar_habitacion'),
    path('habitaciones/<int:pk>/eliminar/', views.eliminar_habitacion, name='eliminar_habitacion'),

    path('clientes/', views.lista_clientes, name='lista_clientes'),
    path('clientes/nuevo/', views.crear_cliente, name='crear_cliente'),
    path('clientes/<int:pk>/', views.detalle_cliente, name='detalle_cliente'),
    path('clientes/<int:pk>/editar/', views.editar_cliente, name='editar_cliente'),
    path('clientes/<int:pk>/eliminar/', views.eliminar_cliente, name='eliminar_cliente'),

    path('reservaciones/', views.lista_reservaciones, name='lista_reservaciones'),
    path('reservaciones/nueva/', views.crear_reservacion, name='crear_reservacion'),
    path('reservaciones/<int:pk>/', views.detalle_reservacion, name='detalle_reservacion'),
    path('reservaciones/<int:pk>/editar/', views.editar_reservacion, name='editar_reservacion'),
    path('reservaciones/<int:pk>/cancelar/', views.cancelar_reservacion, name='cancelar_reservacion'),

    path('disponibilidad/', views.consultar_disponibilidad, name='consultar_disponibilidad'),
]
